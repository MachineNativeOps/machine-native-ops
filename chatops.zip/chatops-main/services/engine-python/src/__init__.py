# services/engine-python/src/__init__.py
"""chatops Engine - gRPC Processing Service"""

__version__ = "0.1.0"
