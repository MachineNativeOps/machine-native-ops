# services

- `engine-python`: local governance engine + metrics endpoint (stdlib http server)
- `gateway-ts`: simple gateway placeholder (no external deps required)

Both are designed to be CI-friendly and runnable locally without extra infrastructure.
