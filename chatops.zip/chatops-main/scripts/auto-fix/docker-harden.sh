#!/usr/bin/env bash
set -euo pipefail
echo "docker-harden: stub (hadolint + base image rules)"
