#!/usr/bin/env bash
set -euo pipefail
echo "go-refresh: stub (go mod tidy)"
