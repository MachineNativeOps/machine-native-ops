#!/usr/bin/env bash
set -euo pipefail
echo "kustomize-sync: stub"
