#!/usr/bin/env bash
set -euo pipefail
echo "opa-evaluate: stub"
