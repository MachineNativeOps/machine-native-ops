#!/usr/bin/env bash
set -euo pipefail
echo "node-refresh: stub (pnpm install)"
