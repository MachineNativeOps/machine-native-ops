#!/usr/bin/env bash
set -euo pipefail
echo "kustomize-diff: stub"
