#!/usr/bin/env bash
set -euo pipefail
echo "verify-post-rollback: stub-ok"
