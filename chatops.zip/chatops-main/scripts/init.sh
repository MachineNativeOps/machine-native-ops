#!/usr/bin/env bash
set -euo pipefail
echo "init: ok"
