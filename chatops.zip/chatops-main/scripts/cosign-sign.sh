#!/usr/bin/env bash
set -euo pipefail
echo "cosign-sign: stub (replace with cosign sign --keyless ...)"
