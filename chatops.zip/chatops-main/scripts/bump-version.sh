#!/usr/bin/env bash
set -euo pipefail
echo "bump-version: stub (update package.json + changelog)"
