#!/usr/bin/env bash
set -euo pipefail
echo "gatekeeper-validate: stub"
