---
name: Bug report
about: Create a report to help us improve
title: "[bug] "
labels: bug
assignees: ''
---

## Describe the bug
## Steps to reproduce
## Expected behavior
## Evidence
- logs:
- artifacts links:
- trace id:
