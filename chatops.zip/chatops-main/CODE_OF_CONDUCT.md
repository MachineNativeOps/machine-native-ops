# Code of Conduct

We follow a professional, inclusive and respectful standard.

- Be respectful.
- Assume good intent.
- No harassment, discrimination or doxxing.
- Security issues: report privately per `docs/SECURITY.md` (or `SECURITY.md`).
