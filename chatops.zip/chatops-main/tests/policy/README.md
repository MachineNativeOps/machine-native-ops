# Policy Tests

OPA/Rego policy unit tests.

## Run

```bash
make policy   # runs conftest verify
opa test policies/opa -v
```
